package aplicacao;

import conexaomysql.Conexao;
import conexaomysql.Modelo.Entrega;
import conexaomysql.Repositorio.EntregaRepositorio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

public class MainGUI {
    private static Connection conexao;

    public static void main(String[] args) {
        try {
            conexao = Conexao.getConexao();
            if (conexao == null) {
                throw new SQLException("Não foi possível estabelecer conexão com o banco de dados.");
            }

            // Criação da janela principal
            JFrame frame = new JFrame("Edson B. Transporte");
            frame.setSize(400, 300);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLayout(new BorderLayout());

            JLabel label = new JLabel("Bem-vindo ao Sistema de Entregas! Edson B. Transportes" , SwingConstants.CENTER);
            label.setFont(new Font("Arial", Font.BOLD, 16));
            frame.add(label, BorderLayout.NORTH);

            JPanel buttonPanel = new JPanel();
            buttonPanel.setLayout(new GridLayout(3, 1, 10, 10));

            JButton btnFuncionario = new JButton("Funcionário");
            JButton btnAdministrador = new JButton("Administrador");
            JButton btnSair = new JButton("Sair");

            // Definindo o tamanho preferido dos botões
            Dimension buttonSize = new Dimension(200, 30);
            btnFuncionario.setPreferredSize(buttonSize);
            btnAdministrador.setPreferredSize(buttonSize);
            btnSair.setPreferredSize(buttonSize);

            buttonPanel.add(btnFuncionario);
            buttonPanel.add(btnAdministrador);
            buttonPanel.add(btnSair);

            frame.add(buttonPanel, BorderLayout.CENTER);

            // Ações dos botões
            btnFuncionario.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    menuFuncionario();
                }
            });

            btnAdministrador.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    menuAdministrador();
                }
            });

            btnSair.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    System.exit(0);
                }
            });

            // Exibe a janela
            frame.setVisible(true);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao estabelecer conexão com o banco de dados: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Menu do funcionário
    private static void menuFuncionario() {
        JFrame frame = new JFrame("Menu do Funcionário");
        frame.setSize(400, 300);
        frame.setLayout(new FlowLayout());

        JButton btnVisualizarTodas = new JButton("Visualizar todas as entregas");
        JButton btnAlterarStatus = new JButton("Alterar status da entrega");
        JButton btnVoltar = new JButton("Voltar");

        // Definindo o tamanho preferido dos botões
        Dimension buttonSize = new Dimension(200, 30);
        btnVisualizarTodas.setPreferredSize(buttonSize);
        btnAlterarStatus.setPreferredSize(buttonSize);
        btnVoltar.setPreferredSize(buttonSize);

        frame.add(btnVisualizarTodas);
        frame.add(btnAlterarStatus);
        frame.add(btnVoltar);

        btnVisualizarTodas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                visualizarTodasEntregas();
            }
        });

        btnAlterarStatus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                alterarStatusEntrega();
            }
        });

        btnVoltar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });

        frame.setVisible(true);
    }

    // Método para visualizar todas as entregas
    private static void visualizarTodasEntregas() {
        try {
            EntregaRepositorio er = new EntregaRepositorio(conexao);
            List<Entrega> entregas = er.listarTodasEntregas();

            StringBuilder mensagem = new StringBuilder("Todas as Entregas:\n");
            for (Entrega entrega : entregas) {
                mensagem.append("ID Pedido: ").append(entrega.getIdPedido()).append(", Data Entrega: ")
                        .append(entrega.getDataEntrega()).append(", Status: ").append(entrega.getStatus())
                        .append(", ID Motorista: ").append(entrega.getIdMotorista()).append("\n");
            }
            JOptionPane.showMessageDialog(null, mensagem.toString());
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao visualizar entregas: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Método para alterar o status da entrega
    private static void alterarStatusEntrega() {
        JTextField idField = new JTextField(5);
        JTextField statusField = new JTextField(20);

        JPanel panel = new JPanel();
        panel.add(new JLabel("ID da Entrega:"));
        panel.add(idField);
        panel.add(Box.createHorizontalStrut(15)); // a spacer
        panel.add(new JLabel("Novo Status:"));
        panel.add(statusField);

        int result = JOptionPane.showConfirmDialog(null, panel,
                "Alterar Status da Entrega", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            int idEntrega = Integer.parseInt(idField.getText());
            String novoStatus = statusField.getText();
            try {
                EntregaRepositorio er = new EntregaRepositorio(conexao);
                er.atualizarStatusEntrega(idEntrega, novoStatus);
                JOptionPane.showMessageDialog(null, "Status da entrega atualizado com sucesso.");
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao alterar status da entrega: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    // Menu do administrador
    private static void menuAdministrador() {
        JFrame frame = new JFrame("Menu do Administrador");
        frame.setSize(400, 300);
        frame.setLayout(new FlowLayout());

        JButton btnAdicionarEntrega = new JButton("Adicionar nova entrega");
        JButton btnVisualizarPendentes = new JButton("Visualizar entregas pendentes");
        JButton btnVoltar = new JButton("Voltar");

        // Definindo o tamanho preferido dos botões
        Dimension buttonSize = new Dimension(200, 30);
        btnAdicionarEntrega.setPreferredSize(buttonSize);
        btnVisualizarPendentes.setPreferredSize(buttonSize);
        btnVoltar.setPreferredSize(buttonSize);

        frame.add(btnAdicionarEntrega);
        frame.add(btnVisualizarPendentes);
        frame.add(btnVoltar);

        btnAdicionarEntrega.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarEntrega();
            }
        });

        btnVisualizarPendentes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                visualizarEntregasPendentes();
            }
        });

        btnVoltar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });

        frame.setVisible(true);
    }

    // Método para adicionar uma nova entrega
    private static void adicionarEntrega() {
        JTextField idPedidoField = new JTextField(5);
        JTextField idMotoristaField = new JTextField(5);

        JPanel panel = new JPanel();
        panel.add(new JLabel("ID do Pedido:"));
        panel.add(idPedidoField);
        panel.add(Box.createHorizontalStrut(15)); // a spacer
        panel.add(new JLabel("ID do Motorista:"));
        panel.add(idMotoristaField);

        String[] options = {"Sim", "Não"};
        int result = JOptionPane.showConfirmDialog(null, panel,
                "Adicionar Nova Entrega", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            int idPedido = Integer.parseInt(idPedidoField.getText());
            int idMotorista = Integer.parseInt(idMotoristaField.getText());

            int entregue = JOptionPane.showOptionDialog(null,
                    "Pedido entregue?",
                    "Status da Entrega",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null, options, options[1]);

            String status = (entregue == JOptionPane.YES_OPTION) ? "Concluída" : "Pendente";

            Entrega entrega = new Entrega(idPedido, new Date(), status, idMotorista);
            try {
                EntregaRepositorio er = new EntregaRepositorio(conexao);
                er.adicionarEntrega(entrega);
                JOptionPane.showMessageDialog(null, "Entrega adicionada com sucesso.");
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao adicionar entrega: \n verifique se o ID existe ");
                e.printStackTrace();
            }
        }
    }

    // Método para visualizar entregas pendentes
    private static void visualizarEntregasPendentes() {
        try {
            EntregaRepositorio er = new EntregaRepositorio(conexao);
            List<Entrega> entregas = er.listarEntregasPendentes();

            StringBuilder mensagem = new StringBuilder("Entregas Pendentes:\n");
            for (Entrega entrega : entregas) {
                mensagem.append("ID Pedido: ").append(entrega.getIdPedido()).append(", Data Entrega: ")
                        .append(entrega.getDataEntrega()).append(", Status: ").append(entrega.getStatus())
                        .append(", ID Motorista: ").append(entrega.getIdMotorista()).append("\n");
            }
            JOptionPane.showMessageDialog(null, mensagem.toString());
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao visualizar entregas pendentes: ");
            e.printStackTrace();
        }
    }
}

