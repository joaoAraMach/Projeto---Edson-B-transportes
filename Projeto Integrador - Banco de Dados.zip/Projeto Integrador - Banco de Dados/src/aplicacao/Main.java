package aplicacao;

import conexaomysql.Conexao;
import conexaomysql.Modelo.Entrega;
import conexaomysql.Repositorio.EntregaRepositorio;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static Connection conexao;

    public static void main(String[] args) {
        try {
            conexao = Conexao.getConexao();
            if (conexao == null) {
                throw new SQLException("Não foi possível estabelecer conexão com o banco de dados.");
            }

            Scanner scanner = new Scanner(System.in);
            int opcao;

            System.out.println("Bem-vindo ao Sistema de Entregas!");

            // Menu de escolha entre funcionário e administrador
            do {
                System.out.println("\nEscolha o tipo de usuário:");
                System.out.println("1 - Funcionário");
                System.out.println("2 - Administrador");
                System.out.println("0 - Sair");
                System.out.print("Opção: ");
                opcao = scanner.nextInt();

                switch (opcao) {
                    case 1:
                        menuFuncionario();
                        break;
                    case 2:
                        menuAdministrador();
                        break;
                    case 0:
                        System.out.println("Saindo do Sistema de Entregas. Até logo!");
                        break;
                    default:
                        System.out.println("Opção inválida. Por favor, escolha uma opção válida.");
                }
            } while (opcao != 0);
        } catch (SQLException e) {
            System.out.println("Erro ao estabelecer conexão com o banco de dados: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Menu do funcionário
    private static void menuFuncionario() {
        Scanner scanner = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("\nMenu do Funcionário:");
            System.out.println("1 - Visualizar todas as entregas");
            System.out.println("2 - Alterar status da entrega");
            System.out.println("0 - Voltar");
            System.out.print("Opção: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    visualizarTodasEntregas();
                    break;
                case 2:
                    alterarStatusEntrega();
                    break;
                case 0:
                    System.out.println("Voltando ao menu principal...");
                    break;
                default:
                    System.out.println("Opção inválida. Por favor, escolha uma opção válida.");
            }
        } while (opcao != 0);
    }

    // Método para visualizar todas as entregas
    private static void visualizarTodasEntregas() {
        try {
            EntregaRepositorio er = new EntregaRepositorio(conexao);
            List<Entrega> entregas = er.listarTodasEntregas();

            System.out.println("\nTodas as Entregas:");
            for (Entrega entrega : entregas) {
                System.out.println("ID Pedido: " + entrega.getIdPedido() + ", Data Entrega: " + entrega.getDataEntrega() +
                        ", Status: " + entrega.getStatus() + ", ID Motorista: " + entrega.getIdMotorista());
            }
        } catch (SQLException e) {
            System.out.println("Erro ao visualizar entregas: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Método para alterar o status da entrega
    private static void alterarStatusEntrega() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o ID da entrega que deseja atualizar: ");
        int idEntrega = scanner.nextInt();
        scanner.nextLine(); // Consumir quebra de linha

        System.out.print("Digite o novo status da entrega (Pendente, Concluída, Em andamento): ");
        String novoStatus = scanner.nextLine();

        try {
            EntregaRepositorio er = new EntregaRepositorio(conexao);
            er.atualizarStatusEntrega(idEntrega, novoStatus);
            System.out.println("Status da entrega atualizado com sucesso.");
        } catch (SQLException e) {
            System.out.println("Erro ao alterar status da entrega: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Menu do administrador
    private static void menuAdministrador() {
        Scanner scanner = new Scanner(System.in);
        int opcao;

        // Implementar a lógica do menu do administrador
        do {
            System.out.println("\nMenu do Administrador:");
            System.out.println("1 - Adicionar nova entrega");
            System.out.println("2 - Visualizar entregas pendentes");
            System.out.println("0 - Voltar");
            System.out.print("Opção: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    adicionarEntrega();
                    break;
                case 2:
                    visualizarEntregasPendentes();
                    break;
                case 0:
                    System.out.println("Voltando ao menu principal...");
                    break;
                default:
                    System.out.println("Opção inválida. Por favor, escolha uma opção válida.");
            }
        } while (opcao != 0);
    }

    // Método para adicionar uma nova entrega
    private static void adicionarEntrega() {
        Scanner sc = new Scanner(System.in);
        int escolha;
        int idPedido;
        Date dataEntrega = new Date();
        String status;
        int idMotorista;

        System.out.println("Digite o ID do pedido: ");
        idPedido = Integer.parseInt(sc.nextLine());

        do {
            System.out.println("Pedido entregue?\n\n[1] - Sim\n[2] - Não\n\n");
            escolha = Integer.parseInt(sc.nextLine());
        } while (escolha != 1 && escolha != 2);

        if (escolha == 1) {
            status = "Concluída";
        } else {
            status = "Pendente";
        }

        System.out.println("Digite o ID do motorista: ");
        idMotorista = Integer.parseInt(sc.nextLine());

        Entrega entrega = new Entrega(idPedido, dataEntrega, status, idMotorista);

        try {
            EntregaRepositorio er = new EntregaRepositorio(conexao);
            er.adicionarEntrega(entrega);
            System.out.println("Entrega adicionada com sucesso.");
        } catch (SQLException e) {
            System.out.println("Erro ao adicionar entrega: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Método para visualizar entregas pendentes
    private static void visualizarEntregasPendentes() {
        try {
            EntregaRepositorio er = new EntregaRepositorio(conexao);
            List<Entrega> entregas = er.listarEntregasPendentes();

            System.out.println("\nEntregas Pendentes:");
            for (Entrega entrega : entregas) {
                System.out.println("ID Pedido: " + entrega.getIdPedido() + ", Data Entrega: " + entrega.getDataEntrega() +
                        ", Status: " + entrega.getStatus() + ", ID Motorista: " + entrega.getIdMotorista());
            }
        } catch (SQLException e) {
            System.out.println("Erro ao visualizar entregas pendentes: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
