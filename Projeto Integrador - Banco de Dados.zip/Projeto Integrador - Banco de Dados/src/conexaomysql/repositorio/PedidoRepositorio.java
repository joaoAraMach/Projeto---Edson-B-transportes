package conexaomysql.repositorio;

import java.sql.*;
import conexaomysql.Modelo.Pedido;
import java.util.ArrayList;
import java.util.List;

public class PedidoRepositorio {
    private Connection conexao;

    public PedidoRepositorio(Connection conexao) {
        this.conexao = conexao;
    }

    public void adicionarPedido(Pedido pedido) throws SQLException {
        String sql = "INSERT INTO pedido (ID_cliente, data_pedido, status, valor_total) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, pedido.getID_cliente());
            stmt.setDate(2, new java.sql.Date(pedido.getData_pedido().getTime()));
            stmt.setString(3, pedido.getStatus());
            stmt.setDouble(4, pedido.getValor_total());
            stmt.executeUpdate();
        }
    }

    public List<Pedido> listarPedidos() throws SQLException {
        List<Pedido> pedidos = new ArrayList<>();
        String sql = "SELECT * FROM pedido";
        try (Statement stmt = conexao.createStatement()) {
            try (ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    int ID = rs.getInt("ID");
                    int ID_cliente = rs.getInt("ID_cliente");
                    Date data_pedido = rs.getDate("data_pedido");
                    String status = rs.getString("status");
                    double valor_total = rs.getDouble("valor_total");
                    Pedido pedido = new Pedido(ID, ID_cliente, data_pedido, status, valor_total);
                    pedidos.add(pedido);
                }
            }
        }
        return pedidos;
    }

    public void removerPedido(int ID) throws SQLException {
        String sql = "DELETE FROM pedido WHERE ID = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, ID);
            stmt.executeUpdate();
        }
    }
}
