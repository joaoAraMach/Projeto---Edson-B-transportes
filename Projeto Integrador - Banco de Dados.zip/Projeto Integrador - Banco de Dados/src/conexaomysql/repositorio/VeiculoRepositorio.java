package conexaomysql.repositorio;

import java.sql.*;
import conexaomysql.Modelo.Veiculo;
import java.util.ArrayList;
import java.util.List;

public class VeiculoRepositorio {
    private Connection conexao;

    public VeiculoRepositorio(Connection conexao) {
        this.conexao = conexao;
    }

    public void adicionarVeiculo(Veiculo veiculo) throws SQLException {
        String sql = "INSERT INTO veiculo (ID_veiculo, Modelo, Placa) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, veiculo.getID_veiculo());
            stmt.setString(2, veiculo.getModelo());
            stmt.setString(3, veiculo.getPlaca());
            stmt.executeUpdate();
        }
    }

    public List<Veiculo> listarVeiculos() throws SQLException {
        List<Veiculo> veiculos = new ArrayList<>();
        String sql = "SELECT * FROM veiculo";
        try (Statement stmt = conexao.createStatement()) {
            try (ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    int ID = rs.getInt("ID");
                    String ID_veiculo = rs.getString("ID_veiculo");
                    String Modelo = rs.getString("Modelo");
                    String Placa = rs.getString("Placa");
                    Veiculo veiculo = new Veiculo(ID, ID_veiculo, Modelo, Placa);
                    veiculos.add(veiculo);
                }
            }
        }
        return veiculos;
    }

    public void removerVeiculo(int ID) throws SQLException {
        String sql = "DELETE FROM veiculo WHERE ID = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, ID);
            stmt.executeUpdate();
        }
    }
}
