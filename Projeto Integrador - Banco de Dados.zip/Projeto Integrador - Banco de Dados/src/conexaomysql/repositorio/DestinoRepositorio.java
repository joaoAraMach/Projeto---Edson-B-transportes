package conexaomysql.repositorio;

import java.sql.*;
import conexaomysql.Modelo.Destino;
import java.util.ArrayList;
import java.util.List;

public class DestinoRepositorio {
    private Connection conexao;

    public DestinoRepositorio(Connection conexao) {
        this.conexao = conexao;
    }

    public void adicionarDestino(Destino destino) throws SQLException {
        String sql = "INSERT INTO destino (cep, rua, numero, complemento, bairro) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, destino.getCep());
            stmt.setString(2, destino.getRua());
            stmt.setInt(3, destino.getNumero());
            stmt.setString(4, destino.getComplemento());
            stmt.setString(5, destino.getBairro());
            stmt.executeUpdate();
        }
    }

    public List<Destino> listarDestinos() throws SQLException {
        List<Destino> destinos = new ArrayList<>();
        String sql = "SELECT * FROM destino";
        try (Statement stmt = conexao.createStatement()) {
            try (ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    int ID = rs.getInt("ID");
                    String cep = rs.getString("cep");
                    String rua = rs.getString("rua");
                    int numero = rs.getInt("numero");
                    String complemento = rs.getString("complemento");
                    String bairro = rs.getString("bairro");
                    Destino destino = new Destino(ID, cep, rua, numero, complemento, bairro);
                    destinos.add(destino);
                }
            }
        }
        return destinos;
    }

    public void removerDestino(int ID) throws SQLException {
        String sql = "DELETE FROM destino WHERE ID = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, ID);
            stmt.executeUpdate();
        }
    }
}
