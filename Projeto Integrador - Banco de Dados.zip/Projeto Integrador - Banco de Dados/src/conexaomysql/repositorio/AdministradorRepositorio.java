package conexaomysql.Repositorio;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import conexaomysql.Modelo.Administrador;

public class AdministradorRepositorio {
    private Connection conexao;

    public AdministradorRepositorio(Connection conexao) {
        this.conexao = conexao;
    }

    public void adicionarAdministrador(Administrador administrador) throws SQLException {
        String sql = "INSERT INTO administrador (sobrenome, idade, email) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, administrador.getSobrenome());
            stmt.setInt(2, administrador.getIdade());
            stmt.setString(3, administrador.getEmail());
            stmt.executeUpdate();
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    administrador.setID(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Falha ao obter o ID do administrador após inserção.");
                }
            }
        }
    }

    public List<Administrador> listarAdministradores() throws SQLException {
        List<Administrador> administradores = new ArrayList<>();
        String sql = "SELECT * FROM administrador";
        try (Statement stmt = conexao.createStatement()) {
            try (ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    int ID = rs.getInt("ID");
                    String sobrenome = rs.getString("sobrenome");
                    int idade = rs.getInt("idade");
                    String email = rs.getString("email");
                    Administrador administrador = new Administrador(ID, sobrenome, idade, email);
                    administradores.add(administrador);
                }
            }
        }
        return administradores;
    }

    public void removerAdministrador(int ID) throws SQLException {
        String sql = "DELETE FROM administrador WHERE ID = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, ID);
            stmt.executeUpdate();
        }
    }
}
