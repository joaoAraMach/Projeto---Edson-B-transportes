package conexaomysql.repositorio;

import java.sql.*;
import conexaomysql.Modelo.Pagamento;
import java.util.ArrayList;
import java.util.List;

public class PagamentoRepositorio {
    private Connection conexao;

    public PagamentoRepositorio(Connection conexao) {
        this.conexao = conexao;
    }

    public void adicionarPagamento(Pagamento pagamento) throws SQLException {
        String sql = "INSERT INTO pagamento (ID_pedido, data_pagamento, valor, metodo) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, pagamento.getID_pedido());
            stmt.setDate(2, new java.sql.Date(pagamento.getDataPagamento().getTime()));
            stmt.setDouble(3, pagamento.getValor());
            stmt.setString(4, pagamento.getMetodo());
            stmt.executeUpdate();
        }
    }

    public List<Pagamento> listarPagamentos() throws SQLException {
        List<Pagamento> pagamentos = new ArrayList<>();
        String sql = "SELECT * FROM pagamento";
        try (Statement stmt = conexao.createStatement()) {
            try (ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    int ID = rs.getInt("ID");
                    int ID_pedido = rs.getInt("ID_pedido");
                    Date dataPagamento = rs.getDate("data_pagamento");
                    double valor = rs.getDouble("valor");
                    String metodo = rs.getString("metodo");
                    Pagamento pagamento = new Pagamento(ID, ID_pedido, dataPagamento, valor, metodo);
                    pagamentos.add(pagamento);
                }
            }
        }
        return pagamentos;
    }

    public void removerPagamento(int ID) throws SQLException {
        String sql = "DELETE FROM pagamento WHERE ID = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, ID);
            stmt.executeUpdate();
        }
    }
}
