package conexaomysql.repositorio;

import java.sql.*;
import conexaomysql.Modelo.Cliente;
import java.util.ArrayList;
import java.util.List;

public class ClienteRepositorio {
    private Connection conexao;

    public ClienteRepositorio(Connection conexao) {
        this.conexao = conexao;
    }

    public void adicionarCliente(Cliente cliente) throws SQLException {
        String sql = "INSERT INTO cliente (ID_produto, telefone, destino, cpf) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, cliente.getID_produto());
            stmt.setString(2, cliente.getTelefone());
            stmt.setString(3, cliente.getDestino());
            stmt.setString(4, cliente.getCpf());
            stmt.executeUpdate();
        }
    }

    public List<Cliente> listarClientes() throws SQLException {
        List<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT * FROM cliente";
        try (Statement stmt = conexao.createStatement()) {
            try (ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    int ID_cliente = rs.getInt("ID_cliente");
                    int ID_produto = rs.getInt("ID_produto");
                    String telefone = rs.getString("telefone");
                    String destino = rs.getString("destino");
                    String cpf = rs.getString("cpf");
                    Cliente cliente = new Cliente(ID_cliente, ID_produto, telefone, destino, cpf);
                    clientes.add(cliente);
                }
            }
        }
        return clientes;
    }

    public void removerCliente(int ID_cliente) throws SQLException {
        String sql = "DELETE FROM cliente WHERE ID_cliente = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, ID_cliente);
            stmt.executeUpdate();
        }
    }
}

