package conexaomysql.Repositorio;

import java.sql.*;
import conexaomysql.Modelo.LoginFuncionario;
import java.util.ArrayList;
import java.util.List;

public class LoginFuncionarioRepositorio {
    private Connection conexao;

    public LoginFuncionarioRepositorio(Connection conexao) {
        this.conexao = conexao;
    }

    public void adicionarLoginFuncionario(LoginFuncionario login) throws SQLException {
        String sql = "INSERT INTO login_funcionario (senha, email) VALUES (?, ?)";
        try (PreparedStatement stmt = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, login.getSenha());
            stmt.setString(2, login.getEmail());
            stmt.executeUpdate();
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    login.setID(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Falha ao obter o ID do login do funcionário após inserção.");
                }
            }
        }
    }

    public List<LoginFuncionario> listarLoginsFuncionario() throws SQLException {
        List<LoginFuncionario> logins = new ArrayList<>();
        String sql = "SELECT * FROM login_funcionario";
        try (Statement stmt = conexao.createStatement()) {
            try (ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    int ID = rs.getInt("ID");
                    String senha = rs.getString("senha");
                    String email = rs.getString("email");
                    LoginFuncionario login = new LoginFuncionario(ID, senha, email);
                    logins.add(login);
                }
            }
        }
        return logins;
    }

    public void removerLoginFuncionario(int ID) throws SQLException {
        String sql = "DELETE FROM login_funcionario WHERE ID = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, ID);
            stmt.executeUpdate();
        }
    }
}
