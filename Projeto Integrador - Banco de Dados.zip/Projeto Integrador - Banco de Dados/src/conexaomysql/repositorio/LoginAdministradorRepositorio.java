package conexaomysql.repositorio;

import java.sql.*;
import conexaomysql.Modelo.LoginAdministrador;
import java.util.ArrayList;
import java.util.List;

public class LoginAdministradorRepositorio {
    private Connection conexao;

    public LoginAdministradorRepositorio(Connection conexao) {
        this.conexao = conexao;
    }

    public void adicionarLoginAdministrador(LoginAdministrador loginAdministrador) throws SQLException {
        String sql = "INSERT INTO login_administrador (Senha, Email) VALUES (?, ?)";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, loginAdministrador.getSenha());
            stmt.setString(2, loginAdministrador.getEmail());
            stmt.executeUpdate();
        }
    }

    public List<LoginAdministrador> listarLoginsAdministradores() throws SQLException {
        List<LoginAdministrador> loginsAdministradores = new ArrayList<>();
        String sql = "SELECT * FROM login_administrador";
        try (Statement stmt = conexao.createStatement()) {
            try (ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    int ID = rs.getInt("ID");
                    String Senha = rs.getString("Senha");
                    String Email = rs.getString("Email");
                    LoginAdministrador loginAdministrador = new LoginAdministrador(ID, Senha, Email);
                    loginsAdministradores.add(loginAdministrador);
                }
            }
        }
        return loginsAdministradores;
    }

    public void removerLoginAdministrador(int ID) throws SQLException {
        String sql = "DELETE FROM login_administrador WHERE ID = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, ID);
            stmt.executeUpdate();
        }
    }
}
