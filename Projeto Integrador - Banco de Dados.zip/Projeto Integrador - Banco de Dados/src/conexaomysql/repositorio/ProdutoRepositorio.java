package conexaomysql.repositorio;

import java.sql.*;
import conexaomysql.Modelo.Produto;
import java.util.ArrayList;
import java.util.List;

public class ProdutoRepositorio {
    private Connection conexao;

    public ProdutoRepositorio(Connection conexao) {
        this.conexao = conexao;
    }

    public void adicionarProduto(Produto produto) throws SQLException {
        String sql = "INSERT INTO produto (nome, descricao, preco) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, produto.getNome());
            stmt.setString(2, produto.getDescricao());
            stmt.setDouble(3, produto.getPreco());
            stmt.executeUpdate();
        }
    }

    public List<Produto> listarProdutos() throws SQLException {
        List<Produto> produtos = new ArrayList<>();
        String sql = "SELECT * FROM produto";
        try (Statement stmt = conexao.createStatement()) {
            try (ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    int ID = rs.getInt("ID");
                    String nome = rs.getString("nome");
                    String descricao = rs.getString("descricao");
                    double preco = rs.getDouble("preco");
                    Produto produto = new Produto(ID, nome, descricao, preco);
                    produtos.add(produto);
                }
            }
        }
        return produtos;
    }

    public void removerProduto(int ID) throws SQLException {
        String sql = "DELETE FROM produto WHERE ID = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, ID);
            stmt.executeUpdate();
        }
    }
}
