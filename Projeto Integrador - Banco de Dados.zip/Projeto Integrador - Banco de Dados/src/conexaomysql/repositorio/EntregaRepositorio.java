package conexaomysql.Repositorio;

import conexaomysql.Modelo.Entrega;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EntregaRepositorio {
    private Connection conexao;

    public EntregaRepositorio(Connection conexao) {
        this.conexao = conexao;
    }

    public void adicionarEntrega(Entrega entrega) throws SQLException {
        String sql = "INSERT INTO entrega (ID_pedido, data_entrega, status, ID_motorista) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, entrega.getIdPedido());
            stmt.setDate(2, new java.sql.Date(entrega.getDataEntrega().getTime()));
            stmt.setString(3, entrega.getStatus());
            stmt.setInt(4, entrega.getIdMotorista());
            stmt.executeUpdate();
        }
    }

    public List<Entrega> listarEntregasPendentes() throws SQLException {
        List<Entrega> entregas = new ArrayList<>();
        String sql = "SELECT * FROM entrega WHERE status = 'Pendente'";
        try (Statement stmt = conexao.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                int idPedido = rs.getInt("ID_pedido");
                Date dataEntrega = rs.getDate("data_entrega");
                String status = rs.getString("status");
                int idMotorista = rs.getInt("ID_motorista");
                Entrega entrega = new Entrega(idPedido, dataEntrega, status, idMotorista);
                entregas.add(entrega);
            }
        }
        return entregas;
    }

    public List<Entrega> listarTodasEntregas() throws SQLException {
        List<Entrega> entregas = new ArrayList<>();
        String sql = "SELECT * FROM entrega";
        try (Statement stmt = conexao.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                int idPedido = rs.getInt("ID_pedido");
                Date dataEntrega = rs.getDate("data_entrega");
                String status = rs.getString("status");
                int idMotorista = rs.getInt("ID_motorista");
                Entrega entrega = new Entrega(idPedido, dataEntrega, status, idMotorista);
                entregas.add(entrega);
            }
        }
        return entregas;
    }

    public void atualizarStatusEntrega(int id, String novoStatus) throws SQLException {
        String sql = "UPDATE entrega SET status = ? WHERE ID = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, novoStatus);
            stmt.setInt(2, id);
            stmt.executeUpdate();
        }
    }
}
