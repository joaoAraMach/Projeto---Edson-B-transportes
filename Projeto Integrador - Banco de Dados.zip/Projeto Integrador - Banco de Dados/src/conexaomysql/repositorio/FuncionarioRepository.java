package conexaomysql.repositorio;

import java.sql.*;
import conexaomysql.Modelo.Funcionario;
import java.util.ArrayList;
import java.util.List;

public class FuncionarioRepository {
    private Connection conexao;

    public FuncionarioRepository(Connection conexao) {
        this.conexao = conexao;
    }

    public void adicionarFuncionario(Funcionario funcionario) throws SQLException {
        String sql = "INSERT INTO funcionarios (Nome, Sobrenome, Idade, Email, Funcao, ID_veiculos) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, funcionario.getNome());
            stmt.setString(2, funcionario.getSobrenome());
            stmt.setInt(3, funcionario.getIdade());
            stmt.setString(4, funcionario.getEmail());
            stmt.setString(5, funcionario.getFuncao());
            stmt.setString(6, funcionario.getID_veiculos());
            stmt.executeUpdate();
        }
    }

    public List<Funcionario> listarFuncionarios() throws SQLException {
        List<Funcionario> funcionarios = new ArrayList<>();
        String sql = "SELECT * FROM funcionarios";
        try (Statement stmt = conexao.createStatement()) {
            try (ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    int ID = rs.getInt("ID");
                    String nome = rs.getString("Nome");
                    String sobrenome = rs.getString("Sobrenome");
                    int idade = rs.getInt("Idade");
                    String email = rs.getString("Email");
                    String funcao = rs.getString("Funcao");
                    String ID_veiculos = rs.getString("ID_veiculos");
                    Funcionario funcionario = new Funcionario(ID, nome, sobrenome, idade, email, funcao, ID_veiculos);
                    funcionarios.add(funcionario);
                }
            }
        }
        return funcionarios;
    }

    public void removerFuncionario(int ID) throws SQLException {
        String sql = "DELETE FROM funcionarios WHERE ID = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, ID);
            stmt.executeUpdate();
        }
    }
}
