package conexaomysql.Modelo;

public class Cliente {
    private int ID_cliente;
    private int ID_produto;
    private String telefone;
    private String destino;
    private String cpf;

    public Cliente(int ID_cliente, int ID_produto, String telefone, String destino, String cpf) {
        this.ID_cliente = ID_cliente;
        this.ID_produto = ID_produto;
        this.telefone = telefone;
        this.destino = destino;
        this.cpf = cpf;
    }

    public int getID_cliente() {
        return ID_cliente;
    }

    public int getID_produto() {
        return ID_produto;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getDestino() {
        return destino;
    }

    public String getCpf() {
        return cpf;
    }

    public void setID_cliente(int ID_cliente) {
        this.ID_cliente = ID_cliente;
    }

    public void setID_produto(int ID_produto) {
        this.ID_produto = ID_produto;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
}
