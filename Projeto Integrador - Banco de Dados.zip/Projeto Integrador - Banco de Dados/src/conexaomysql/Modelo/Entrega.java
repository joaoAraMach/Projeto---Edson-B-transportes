package conexaomysql.Modelo;

import java.util.Date;

public class Entrega {
    private int id;
    private int idPedido;
    private Date dataEntrega;
    private String status;
    private int idMotorista;

    public Entrega(int idPedido, Date dataEntrega, String status, int idMotorista) {
        this.idPedido = idPedido;
        this.dataEntrega = dataEntrega;
        this.status = status;
        this.idMotorista = idMotorista;
    }

    public int getId() {
        return id;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public Date getDataEntrega() {
        return dataEntrega;
    }

    public String getStatus() {
        return status;
    }

    public int getIdMotorista() {
        return idMotorista;
    }
}
