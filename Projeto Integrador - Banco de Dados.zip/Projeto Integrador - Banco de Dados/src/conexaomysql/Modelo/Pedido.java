package conexaomysql.Modelo;

import java.util.Date;

public class Pedido {
    private int ID;
    private int ID_cliente;
    private Date data_pedido;
    private String status;
    private double valor_total;

    public Pedido(int ID, int ID_cliente, Date data_pedido, String status, double valor_total) {
        this.ID = ID;
        this.ID_cliente = ID_cliente;
        this.data_pedido = data_pedido;
        this.status = status;
        this.valor_total = valor_total;
    }

    public int getID() {
        return ID;
    }

    public int getID_cliente() {
        return ID_cliente;
    }

    public Date getData_pedido() {
        return data_pedido;
    }

    public String getStatus() {
        return status;
    }

    public double getValor_total() {
        return valor_total;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setID_cliente(int ID_cliente) {
        this.ID_cliente = ID_cliente;
    }

    public void setData_pedido(Date data_pedido) {
        this.data_pedido = data_pedido;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setValor_total(double valor_total) {
        this.valor_total = valor_total;
    }
}
