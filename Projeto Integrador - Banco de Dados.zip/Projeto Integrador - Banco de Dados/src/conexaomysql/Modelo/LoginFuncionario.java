package conexaomysql.Modelo;

public class LoginFuncionario {
    private int ID;
    private String senha;
    private String email;

    public LoginFuncionario(int ID, String senha, String email) {
        this.ID = ID;
        this.senha = senha;
        this.email = email;
    }

    public int getID() {
        return ID;
    }

    public String getSenha() {
        return senha;
    }

    public String getEmail() {
        return email;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
