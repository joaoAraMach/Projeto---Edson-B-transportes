package conexaomysql.Modelo;

import java.util.Date;

public class Pagamento {
    private int ID;
    private int ID_pedido;
    private Date dataPagamento;
    private double valor;
    private String metodo;

    // Construtor
    public Pagamento(int ID, int ID_pedido, Date dataPagamento, double valor, String metodo) {
        this.ID = ID;
        this.ID_pedido = ID_pedido;
        this.dataPagamento = dataPagamento;
        this.valor = valor;
        this.metodo = metodo;
    }

    // Getters e Setters
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getID_pedido() {
        return ID_pedido;
    }

    public void setID_pedido(int ID_pedido) {
        this.ID_pedido = ID_pedido;
    }

    public Date getDataPagamento() {
        return dataPagamento;
    }

    public void setDataPagamento(Date dataPagamento) {
        this.dataPagamento = dataPagamento;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getMetodo() {
        return metodo;
    }

    public void setMetodo(String metodo) {
        this.metodo = metodo;
    }
}