package conexaomysql.Modelo;

public class Funcionario {
    private int ID;
    private String nome;
    private String sobrenome;
    private int idade;
    private String email;
    private String funcao;
    private String ID_veiculos;

    public Funcionario(int ID, String nome, String sobrenome, int idade, String email, String funcao, String ID_veiculos) {
        this.ID = ID;
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.idade = idade;
        this.email = email;
        this.funcao = funcao;
        this.ID_veiculos = ID_veiculos;
    }

    public int getID() {
        return ID;
    }

    public String getNome() {
        return nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public int getIdade() {
        return idade;
    }

    public String getEmail() {
        return email;
    }

    public String getFuncao() {
        return funcao;
    }

    public String getID_veiculos() {
        return ID_veiculos;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    public void setID_veiculos(String ID_veiculos) {
        this.ID_veiculos = ID_veiculos;
    }
}
