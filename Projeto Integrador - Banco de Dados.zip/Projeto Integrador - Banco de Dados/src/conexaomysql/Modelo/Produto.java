package conexaomysql.Modelo;

public class Produto {
    private int ID;
    private String nome;
    private String descricao;
    private double preco;

    public Produto(int ID, String nome, String descricao, double preco) {
        this.ID = ID;
        this.nome = nome;
        this.descricao = descricao;
        this.preco = preco;
    }

    public int getID() {
        return ID;
    }

    public String getNome() {
        return nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public double getPreco() {
        return preco;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }
}

