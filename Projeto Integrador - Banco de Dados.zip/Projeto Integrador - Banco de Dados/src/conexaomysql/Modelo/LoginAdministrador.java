package conexaomysql.Modelo;

public class LoginAdministrador {
    private int ID;
    private String Senha;
    private String Email;

    public LoginAdministrador(int ID, String Senha, String Email) {
        this.ID = ID;
        this.Senha = Senha;
        this.Email = Email;
    }

    public int getID() {
        return ID;
    }

    public String getSenha() {
        return Senha;
    }

    public String getEmail() {
        return Email;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setSenha(String Senha) {
        this.Senha = Senha;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }
}
