package conexaomysql.Modelo;

public class Veiculo {
    private int ID;
    private String ID_veiculo;
    private String Modelo;
    private String Placa;

    public Veiculo(int ID, String ID_veiculo, String Modelo, String Placa) {
        this.ID = ID;
        this.ID_veiculo = ID_veiculo;
        this.Modelo = Modelo;
        this.Placa = Placa;
    }

    public int getID() {
        return ID;
    }

    public String getID_veiculo() {
        return ID_veiculo;
    }

    public String getModelo() {
        return Modelo;
    }

    public String getPlaca() {
        return Placa;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setID_veiculo(String ID_veiculo) {
        this.ID_veiculo = ID_veiculo;
    }

    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }

    public void setPlaca(String Placa) {
        this.Placa = Placa;
    }
}
