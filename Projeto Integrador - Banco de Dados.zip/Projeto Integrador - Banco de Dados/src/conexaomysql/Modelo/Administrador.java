package conexaomysql.Modelo;

public class Administrador {
    private int ID;
    private String sobrenome;
    private int idade;
    private String email;

    public Administrador(int ID, String sobrenome, int idade, String email) {
        this.ID = ID;
        this.sobrenome = sobrenome;
        this.idade = idade;
        this.email = email;
    }

    public int getID() {
        return ID;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public int getIdade() {
        return idade;
    }

    public String getEmail() {
        return email;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
