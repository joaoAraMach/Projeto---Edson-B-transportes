package conexaomysql.Modelo;

public class Destino {
    private int ID;
    private String cep;
    private String rua;
    private int numero;
    private String complemento;
    private String bairro;

    public Destino(int ID, String cep, String rua, int numero, String complemento, String bairro) {
        this.ID = ID;
        this.cep = cep;
        this.rua = rua;
        this.numero = numero;
        this.complemento = complemento;
        this.bairro = bairro;
    }

    public int getID() {
        return ID;
    }

    public String getCep() {
        return cep;
    }

    public String getRua() {
        return rua;
    }

    public int getNumero() {
        return numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }
}

