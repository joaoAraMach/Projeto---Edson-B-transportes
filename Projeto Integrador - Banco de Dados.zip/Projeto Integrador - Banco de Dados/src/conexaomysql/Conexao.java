package conexaomysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

    public static Connection getConexao() {
        try {
            String endereco = "jdbc:mysql://localhost/entregas";
            String usuario = "lucas";
            String senha = "Senac@1234";
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(endereco, usuario, senha);
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Erro ao tentar conectar-se: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
}
